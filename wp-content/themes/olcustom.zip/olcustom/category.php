<?php get_header('category'); ?>

<div class="container-fluid">
  <div class="breadcrumbs">
  <ul class="breadcrumb">
  <?php
    if (class_exists('bcn_breadcrumb_trail')) //Also in single.php
    {
      $breadcrumb_trail = new bcn_breadcrumb_trail;
      $breadcrumb_trail->opt['bhome_display'] = false;
      $breadcrumb_trail->fill();
      $root_cat = strtolower(end($breadcrumb_trail->trail)->get_title());
      if (!get_custom('beta')) {
				end($breadcrumb_trail->trail)->set_url("http://openlectures.sg/subjects/".$root_cat);
			} else {
				end($breadcrumb_trail->trail)->set_url("http://openlectures.sg/subjects/".$root_cat.'/market-failure/');
			}
      $breadcrumb_trail->display();
    }
  ?>
  </ul>
</div><!--breadcrumbs-->
  <div class="sidebar">
    <div class="category-well">
    <?php
    if (is_category()) {
			$this_category = get_category($cat);
			if (get_custom('beta'))
			{
				if (get_category_children($this_category->cat_ID) != "") {
					wp_list_categories('orderby=name&order=DESC&hide_empty=0&title_li=&include=172,173&child_of=' . $this_category->cat_ID);
				}
				else {	
					$parent = $this_category->category_parent;
					wp_list_categories('orderby=name&order=DESC&hide_empty=0&title_li=&include=172,173&child_of=' . $parent);
				}
			} else {
				if (get_category_children($this_category->cat_ID) != "") {
					wp_list_categories('hide_empty=0&title_li=&child_of=' . $this_category->cat_ID);
				}
				else {
					$parent = $this_category->category_parent;
					wp_list_categories('hide_empty=0&title_li=&child_of=' . $parent);
				}
			}
    }
    ?>
    </div><!--well-->
  </div><!--sidebar-->
<div class="content"><?php	if(function_exists('get_terms_meta')) {		$cat_pic = get_terms_meta($cat, "category_pic");	}?>
    <div class="hero-unit category-pic" style="background-image:url(/wp-content/uploads/<?php echo $cat_pic[0]; ?>.png)">
    <?php $this_category=get_category($cat); ?>
        <h1 style="font-size:300%"><?php single_cat_title() ?></h1>
        <div class="description">
        <p><?php echo $this_category->description; ?></p>
        </div><!--description-->
    </div><!--hero-unit-->
    <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1; // for pagination
        if (!get_custom('beta')) {
			$num_cols = 3; // set the number of columns here
			query_posts($query_string . '&posts_per_page=16&paged=$paged&orderby=title&order=ASC');
		}
		else {
			$num_cols = 2; // set the number of columns here
			query_posts($query_string . '&posts_per_page=21&paged=$paged&orderby=title&order=ASC');
		}
        if (have_posts()) :
        for ( $i=1 ; $i <= $num_cols; $i++ ) :
        echo '<div id="col-'.$i.'" class="span7">';
        $counter = $num_cols + 1 - $i;
        while (have_posts()) : the_post();
        if( $counter%$num_cols == 0 ) : ?>
        <h4><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>
        <p><?php the_content(); ?></p>
        <?php endif;
        $counter++;
        endwhile;
        rewind_posts();
        echo '</div>'; //closes the column div
        endfor;
        else:
        echo 'no posts';
        endif;
        wp_reset_query();
    ?>    

    <!--<?php wp_pagenavi(); ?>-->

<?php get_footer('category'); ?>