<!DOCTYPE HTML> 
<html lang='en'>
<head>
  <title><?php bloginfo('name'); ?> <?php wp_title('-'); ?></title>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
  <?php function call_scripts() {
		  wp_deregister_script('jquery');
                  wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js', false, '1.6.4');
		  wp_enqueue_script('jquery');	
                  wp_enqueue_script('bootstrap-dropdown', '/wp-content/themes/olcustom/js/bootstrap-dropdown.js', false, null);
          }    
   
          add_action('wp_enqueue_scripts', 'call_scripts');
          ?>
  <?php wp_head(); ?>
</head>
<style type="text/css">
.parent{
	display:table;
	padding-top:20%;
	padding-bottom:10%;
	width:100%;
	height:100%;
}
.child{
	display:table-cell;
	vertical-align:middle;
	text-align:center;
}
input{
   text-align:center;
}
</style>
<body>
<div class="container">
<div class="parent">
  <div class="child">
<h1 style="font-size:500%; padding-bottom:20px;">Open Lectures</h1>
   <form method="get" action="">
          <input type="text" value="Find a lecture" class="span10" placeholder="Find a lecture" onfocus="if(this.value == this.defaultValue) this.value = ''"     name="s" id="s">
        </form>
<div class="row" style="margin-left:10%; padding-top:40px; text-align:center;">
<div class="span2">
<a href="/biology"><span>
<h1 style="font-size:350%;">b</h1>
<p>biology</p></span></a>
</div><!--span2-->
<div class="span2">
<a href="/chemistry"><span>
<h1 style="font-size:350%;">c</h1>
<p>chemistry</p></span></a>
</div><!--span2-->
<div class="span2">
<a href="/economics"><span>
<h1 style="font-size:350%;">e</h1>
<p>economics</p></span></a>
</div><!--span2-->
<div class="span2">
<a href="/mathematics"><span>
<h1 style="font-size:350%;">m</h1>
<p>mathematics</p></span></a>
</div><!--span2-->
<div class="span2">
<a href="/physics"><span>
<h1 style="font-size:350%;">p</h1>
<p>physics</p></span></a>
</div><!--span2-->
<div class="span2">
<a href="/subjects"><span>
<h1 style="font-size:350%;">( )</h1>
<p>all subjects</p></span></a>
</div><!--span2-->
</div><!--subset-row-->
<div id="footer" style="padding-top:25%;">
   <footer>
    <div class="row">
      <div class="span-one-third">
        &copy; Open Lectures SG 2011
      </div><!--span-one-third-->

      <div class="span-two-thirds" style="text-align:right;">
        <?php wp_loginout(); ?> | <a href="/terms-of-use">Terms of Use</a> | <a href="/non-discrimination">Non-discrimination</a>
      </div><!--span-two-thirds-->
      </div><!--row-->
     <footer>
    <?php wp_footer(); ?>
</div><!--#footer-->
  </div><!--child-->
<div><!--parent-->
</div><!--container-->
</body>
</html>
