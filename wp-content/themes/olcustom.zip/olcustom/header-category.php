<!DOCTYPE HTML> 
<html lang='en'>
<head>
  <title><?php bloginfo('name'); ?> <?php wp_title('-'); ?></title>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
  <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri(); ?>/addon.css" type="text/css">
    <?php function call_scripts() {
      wp_enqueue_script('jquery');	
      wp_enqueue_script('bootstrap-dropdown', '/wp-content/themes/olcustom/js/bootstrap-dropdown.js', false, null);
      wp_enqueue_script('jwplayer', '/wp-content/themes/olcustom/jwplayer/jwplayer.js', false, null);
      if (is_page('lecturers')) {
      wp_enqueue_script('quicksand', '/wp-content/themes/olcustom/js/jquery.quicksand.js', false, null);
      wp_enqueue_script('quicksand-lecturers', '/wp-content/themes/olcustom/js/quicksand-lecturers.js', false, null);
      }
      }
      add_action('wp_enqueue_scripts', 'call_scripts');
    ?>
  <?php wp_head(); ?>
</head>
<?php flush(); ?>
<body>
  <div class="topbar" data-dropdown="dropdown">
    <div class="fill">
      <div class="container-fluid">
      	<a class="brand" href="<?php bloginfo('url'); ?>"><img src="/wp-content/uploads/Logo-Fill-White-Web.png" height="20px" style="padding-top:2px; margin-bottom:-4px;"></a>
        <ul class="nav">
          <?php wp_list_pages('sort_column=post_title&title_li='); ?>
          <li class="menu">
            <a class="dropdown-toggle" href='#'>Subjects</a> 
            <ul class="menu-dropdown">
<?php if(get_custom('beta')): ?>
<li><a href="/subjects/economics/market-failure/">Economics</a></li>
<?php else: ?>
              <li><a href="/biology">Biology</a></li>
              <li><a href="/chemistry">Chemistry</a></li>
              <li><a href="/economics">Economics</a></li>
              <li><a href="/mathematics">Mathematics</a></li>
              <li><a href="/physics">Physics</a></li>
<?php endif; ?>
            </ul>
          </li>
					<li class="menu"><a href="http://openlectures.sg/qa">Ask Questions</a></li>
        </ul>
        <form method="get" id="searchform" action="" class="pull-right">
          <input type="text" value="Find a lecture" placeholder="Find a lecture" onfocus="if(this.value == this.defaultValue) this.value = ''" name="s" id="s">
        </form>
      </div><!--container-->
    </div><!--fill-->
  </div><!--topbar-->  