</div><!--container-->
</div><!--content-->

<div class="container" id="footer">
  <footer>
    <div class="row">
      <div class="span-one-third">
        &copy; Open Lectures SG 2011
      </div><!--span-one-third-->
      <div class="span-two-thirds" style="text-align:right;">
        <?php wp_loginout(); ?><!-- | <a href="/terms-of-use">Terms of Use</a> | <a href="/non-discrimination">Non-discrimination</a> -->
      </div><!--span-two-thirds-->
    </div><!--row-->
  </footer>
</div><!--container/footer-->
<?php wp_footer(); ?>
</body>
</html>
