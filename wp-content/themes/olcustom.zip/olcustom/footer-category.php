</div><!--container-->
</div><!--content-->

<div class="container-fluid">
  <footer>
    <div class="row">
      <div class="span4">
        &copy; Open Lectures SG 2011
      </div><!--span4-->
      <div class="pull-right">
        <?php wp_loginout(); ?> | <a href="/terms-of-use">Terms of Use</a> | <a href="/non-discrimination">Non-discrimination</a>
      </div><!--span10-->
    </div><!--row-->
  </footer>
</div><!--container/footer-->
<?php wp_footer(); ?>
</body>
</html>
