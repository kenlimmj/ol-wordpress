<!DOCTYPE HTML>
<html lang='en'>
<head>
  <title>Open Lectures - The Revolution of Education</title>

  <!-- Call stylesheets for foundational formatting and page-specific add-ons -->
  <link rel="stylesheet" media="screen" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css">
  <link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri(); ?>/launch-addon.css" type="text/css">
    <?php function call_scripts() {
    wp_enqueue_script('jquery');  
    wp_enqueue_script('jwplayer', '/wp-content/themes/olcustom/jwplayer/jwplayer.js', false, null);
    }
    add_action('wp_enqueue_scripts', 'call_scripts');
    ?>
  <?php wp_head(); ?>
</head>
<?php flush(); ?>
<body>
<div class="content" id="gallery">
  <div class="container">

<!-- Logo Block -->
<section id="logo">
   <div class="masthead">
      <a href="<?php bloginfo('url'); ?>"><img src="http://openlectures.sg/wp-content/uploads/Masthead-Fill-Gray-Web.png" width="100%"></a>
  </div><!--masthead-->
</section>
<!-- End Logo Block --> 

<!-- Attention Block -->
<section id="attention">
  <hr>
    <ul class="media-grid">
      <li><a href="http://www.youtube.com/watch?v=S1bqRc1Ovlo" class="lightbox" rel="videos"><img src="/wp-content/uploads/Linan.png" class="thumbnail" width="125px";></a></li>
      <li><a href="http://www.youtube.com/watch?v=xZpdC_X2t5Q" class="lightbox" rel="videos"><img src="/wp-content/uploads/Gary.png" class="thumbnail" width="125px"></a></li>
      <li><a href="#http://www.youtube.com/watch?v=fUNnJfaYgB4" class="lightbox" rel="videos"><img src="/wp-content/uploads/Jun-Le.png" class="thumbnail" width="125px"></a></li>
      <li><a href="http://www.youtube.com/watch?v=nY7c1v93aVk" class="lightbox" rel="videos"><img src="/wp-content/uploads/Aidi.png" class="thumbnail" width="125px"></a></li>
      <li><a href="http://www.youtube.com/watch?v=i6MdyzRgXFY" class="lightbox" rel="videos"><img src="/wp-content/uploads/Kenneth.png" class="thumbnail" width="125px"></a></li>
      <li><a href="http://www.youtube.com/watch?v=fOPE3qhHC2g" class="lightbox" rel="videos"><img src="/wp-content/uploads/Samuel.png" class="thumbnail" width="125px"></a></li>
    </ul>
  <hr>
  <div class="motto">
  <h1>Learning, not studying. Sharing, not teaching.</h1>
  </div><!--motto-->
  <hr>
  </section>
<!-- End Attention Block -->

<!-- Signup Form -->
<section id="signup-form">
  <div class="lbox">
  <form id="form" action="http://openlectures.us2.list-manage1.com/subscribe/post" method="post">
    <h6>Get that competitive edge. We'll let you know when the beta's ready.</h6>
    <input type="hidden" name="u" value="8e7b52f852ab6d1e494fa040e">
    <input type="hidden" name="id" value="ee7391fa84">
    <input type="email" autocapitalize="off" autocorrect="off" name="MERGE0" id="MERGE0" class="span10" value="" placeholder="Cough up the email address now...">
  <h6>Got Twitter? We'll follow back.</h6>
    <div class="input-prepend">
      <span class="add-on">@</span><input type="text" name="MERGE1" id="MERGE1" size="20" value="" placeholder="openlecturessg">
    </div><!--input-prepend-->

    <div class="actions">
      <input type="submit" class="btn large" value="Keep me in the Loop">
    </div><!--actions-->
  </form>
  </div><!--form-->
  </section>
<!-- End Signup Form -->

<!-- Information Block -->
<section id="information">
  <div class="row">
    <div class="span-two-thirds">
      <p style="text-align:justify;">We want to make education free and accessible for everyone. You shouldn't be waiting for classes - they should be waiting for you. So we've put together something incredible. We've taken a tried-and-tested concept, and done it the way young people would like it - the way it should be done.</p>
      <p><strong>More information appears every week. Sign up to be notified.<br/>Prepare to do what your school dares not.</strong></p>
    </div><!--span-two-thirds-->

    <div class="span-one-third">
      <div class="well buttons">
      <a href="?lightbox[height]=260#form" class="lightbox"><h1>Get Early Access</h1></a>
      </div><!--well-->
      <div class="well buttons lbox">
      <a href="#" class="lightbox"><h1>Spread The Word</h1></a>
      </div><!--well-->
      <div class="well buttons">
      <a href="mailto:hello@openlectures.sg"><h1>Contact Us</h1></a>
      </div><!--well-->
    </div><!--span-one-third-->
  </div><!--row-->
  </section>
<!-- End Information Block -->

<?php get_footer(); ?>