<?php
function get_the_subcategory()
{
$categories = get_the_category();

// get the sub category if we have them
foreach ($categories as $cat)
{
$parent = $cat->category_parent;

if ($parent != 0 )
{
$sub_cat_ID = $cat->cat_ID;
}
}

if (!$sub_cat_ID)
{
return false;
}
else
{
return $sub_cat_ID;
}
}

// Disable the Wordpress Admin Bar for all but admins.
if (!current_user_can('administrator')):
show_admin_bar(false);
endif;

// Don't add the wp-includes/js/l10n.js?ver=20101110 script to non-admin pages
function remove_l10n_js(){
  if (!is_admin()){
    wp_deregister_script('l10n');
  }
}
add_action('wp_print_scripts', 'remove_l10n_js');


// Hide visual and html editor
// add_action('admin_head', 'hide_post_box');
function hide_post_box() {
?>
 <style>
 #editor-toolbar{ display:none; }
 #editorcontainer{ display:none; }
 #quicktags { display:none; }
 #post-status-info { display:none; }
 </style>
<?php
}
// End hide visual and html editor

// Declare theme support for post-thumbnails
	if ( function_exists( 'add_theme_support' ) ) { 
	  add_theme_support( 'post-thumbnails' ); 
	}
// End declare theme support

// Redirect to Post if Search returns only single result
	add_action('template_redirect', 'single_result');
	function single_result() {
		if (is_search()) {
			global $wp_query;
			if ($wp_query->post_count == 1) {
				wp_redirect( get_permalink( $wp_query->posts['0']->ID ) );
			}
		}
	}
// End post redirect

// Change excerpt length
	function new_excerpt_length($length) {
		return 90;
	}
	add_filter('excerpt_length', 'new_excerpt_length');
// End change excerpt length

// Change excerpt default [...] ending
	function new_excerpt_more($more) {
		global $post;
		return '...<a href="'. get_permalink($post->ID) . '">>></a>';
	}
	add_filter('excerpt_more', 'new_excerpt_more');
// End change excerpt default ending

// Remove junk from head
	remove_action('wp_head', 'rsd_link');
	remove_action('wp_head', 'wp_generator');
	remove_action('wp_head', 'feed_links', 2);
	remove_action('wp_head', 'index_rel_link');
	remove_action('wp_head', 'wlwmanifest_link');
	remove_action('wp_head', 'feed_links_extra', 3);
	remove_action('wp_head', 'start_post_rel_link', 10, 0);
	remove_action('wp_head', 'parent_post_rel_link', 10, 0);
	remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);
// End remove junk from head

?>