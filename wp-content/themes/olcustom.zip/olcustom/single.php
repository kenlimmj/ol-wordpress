<?php get_header(); ?>
<link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri(); ?>/page-addon.css" type="text/css">

  <?php if ( ! have_posts() ) : ?>
   <h1>Not Found</h1>
    <p>Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post</p>
   <?php endif; ?>
  <?php while ( have_posts() ) : the_post(); ?>
<!--         <?php previous_post_link('<img src="/wp-content/uploads/navleft.png" width=50px>','&#8592; Previous Lecture', TRUE); ?>
        <?php next_post_link('<img src="/wp-content/uploads/navright.png" width=50px>','Next Lecture &#8594;', TRUE); ?> -->
  <div class="container">
    <div class="content">
      <div class="page-header">
        <h1><?php the_title(); ?> <small>by 
        <?php the_author_posts_link(); ?></small></h1>
      </div><!--pageheader-->

      <div class="breadcrumbs">
        <ul class="breadcrumb">
          <?php
          /*if(function_exists('bcn_display'))
						{
							bcn_display();
						}*/
					//Hacked to redirect the root category to the correct page, better make sure it's all named correctly!
					//Don't forget it's also in category.php
					if (class_exists('bcn_breadcrumb_trail'))
					{
						$breadcrumb_trail = new bcn_breadcrumb_trail;
						$breadcrumb_trail->opt['bhome_display'] = false;
						$breadcrumb_trail->fill();
						$root_cat = strtolower(end($breadcrumb_trail->trail)->get_title());
						if (!get_custom('beta')) {
							end($breadcrumb_trail->trail)->set_url("http://openlectures.sg/subjects/".$root_cat);
						} else {
							end($breadcrumb_trail->trail)->set_url("http://openlectures.sg/subjects/".$root_cat.'/market-failure/');
						}
						$breadcrumb_trail->display();
					}
          ?>
        </ul>
      </div><!--breakcrumbs-->
	<?php if ( is_archive() || is_search() ) : // Only display excerpts for archives and search. ?>
        <?php the_excerpt(); ?>
        <?php else : ?>
        <div id="content">
          <video src="<?php echo get_post_meta($post->ID, 'videourl', true); ?>" id="container" poster="/wp-content/uploads/Ending-Wrapper.png"/></video>
        	<hr>
        	<p><?php echo get_post_meta($post->ID, 'description', true); ?></p>
          <?php the_content('Read More'); ?>
          <script type='text/javascript'>
            jwplayer('container').setup({
              'flashplayer': '/wp-content/themes/olcustom/jwplayer/player.swf',
              'width': '820',
              'height': '505',
              'plugins': {
                    'hd-2': {'state': 'true'},
          	  'backstroke-1' : {},
          	  'lightsout-1': {},
          	       },
              'controlbar': 'bottom',
              'logo': {
          	'file': '/wp-content/uploads/Logo-Player.png',
          	'position': 'top-left',
          },
              'skin': '/wp-content/themes/olcustom/jwplayer/schoon.zip'
            });
          </script>
        </div><!--content-->
				<hr>
       <?php endif; ?>
       <?php endwhile; ?>  
      <?php get_footer('fluid'); ?>