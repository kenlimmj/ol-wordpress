<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en" xmlns:fb="http://ogp.me/ns/fb#"> <!--<![endif]-->
<head>

  <!-- Basic Page Needs
  ================================================== -->
  <meta charset="utf-8">
  <meta http-equiv=”X-UA-Compatible” content=”IE=9″ />
  <meta property="og:title" content="openlectures" />
  <meta property="og:type" content="school" />
  <meta property="og:url" content="http://facebook.com/OpenLectures" />
  <meta property="og:image" content="" />
  <meta property="og:site_name" content="openlectures" />
  <meta property="fb:admins" content="100000730951420" />
  <title>Open Lectures <?php wp_title('-'); ?></title>

  <!-- Mobile Specific Metas
  ================================================== -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <!-- CSS
  ================================================== -->
  <link rel="stylesheet" href="/wp-content/themes/olresponsive/style.css">
  <link rel="stylesheet" href="/wp-content/themes/olresponsive/ol.css">
  <link rel="stylesheet" href="/wp-content/themes/olresponsive/font-awesome.css">
  <link rel="stylesheet" href="/wp-content/themes/olresponsive/prettify.css">
  <link rel="stylesheet" href="/wp-content/themes/olresponsive/timeline.min.css">

  <!--Scripts
  ================================================== -->
  <?php add_action('wp_enqueue_scripts', 'call_scripts'); ?>
  <?php wp_head(); ?>
  <?php flush(); ?>

<div class="navbar navbar-fixed-top">
  <div class="navbar-inner">
    <div class="container">
      <a class="brand" href="http://localhost"><span class="openlectures"><b>open</b>lectures</span></a>
      <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <div class="nav-collapse">
        <ul class="nav">
          <!-- <ul class="nav"> -->
            <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="icon-th-list"></i> Subjects<b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="/economics">Economics</a></li>
                <li><a href="/chemistry">Chemistry</a></li>
                <li><a href="/physics">Physics</a></li>
                <li><a href="/literature">Literature</a></li>
                <li><a href="/miscellaneous">Miscellaneous</a></li>
                <li class="divider"></li>
                <li><a href="#" class="muted">Mathematics</a></li>
                <li><a href="#" class="muted">Biology</a></li>
                <li><a href="#" class="muted">Geography</a></li>
              </ul>
            </li>
          <!-- </ul> -->
          <li><a href="/about-us"><i class="icon-user"></i> About Us</a></li>
          <li><a href="/press"><i class="icon-camera"></i> Press</a></li>
          <li><a href="/opportunities"><i class="icon-asterisk"></i>Opportunities</a></li>
        </ul>
        <form method="get" class="navbar-search pull-right visible-desktop" action="<?php echo home_url( '/' ); ?>">
          <input type="text" class="search-query" placeholder="Find a lecture" name="s" id="search" value="<?php the_search_query(); ?>">
        </form>
      </div><!--navcollapse-->
    </div><!--container-->
  </div><!--navbarinner-->
</div><!--navbar-->
</head>