<?php get_header(); ?>
  <div class="container">
        <?php if ( have_posts() ) : the_post(); ?>
        <div class="page-header">
          <?php
          $title = the_title('','',false);
          $title_short = substr($title,5);
          ?>
        <h1><?php echo ucwords($title_short); ?></h1>
        </div><!--pageheader-->
       <?php
        $refilm=get_post_meta($post->ID, 'pending_refilm', true);
        $info=get_post_meta($post->ID, 'additional_information', true);
        if ($refilm && $info) {
          echo '<div class="row">';
          echo '<div class="span6">';
          echo '<div class="alert alert-info fade in">';
          echo '<a class="close" data-dismiss="alert">×</a>';
          echo 'Additional information, such as errata or supplementary notes, accompanies this lecture. Scroll down to check it out!';
          echo '</div><!--alert-->';
          echo '</div><!--span6-->';
          echo '<div class="span6">';
          echo '<div class="alert alert-error fade in">';
          echo '<a class="close" data-dismiss="alert">×</a>';
          echo 'This lecture has been scheduled for a re-film because of community feedback. Read more about our standards <a href="/standards">here</a>';
          echo '</div><!--alert-->';
          echo '</div><!--span6-->';
        }
        elseif ($refilm) {
          echo '<div class="alert alert-error fade in">';
          echo '<a class="close" data-dismiss="alert">×</a>';
          echo 'This lecture has been scheduled for a re-film because of community feedback. Read more about our standards <a href="/standards">here</a>';
          echo '</div><!--alert-->';
        }
        elseif ($info) {
          echo '<div class="alert alert-info fade in">';
          echo '<a class="close" data-dismiss="alert">×</a>';
          echo 'Additional information, such as errata or supplementary notes, accompanies this lecture. Scroll down to check it out!';
          echo '</div><!--alert-->';
        }
        ?>
        <div class="row">
        <div class="span9">
          <div class="video cbar-none">
                  <video preload src="<?php echo get_post_meta($post->ID, 'video_url', true); ?>" id="container" poster="/wp-content/themes/olresponsive/img/poster.png"/></video>
              </div><!--video-->
        </div><!--span9-->
        <?php
          $subject = get_the_category();
          $subject_ID = $subject[0]->cat_ID;
          $parentcatID = pa_category_top_parent_id($subject_ID);
          $post_ID = $post->ID;
          $post_list = objectToArray(get_posts('cat='.$subject_ID.'&post_status=publish&orderby=title&order=ASC&posts_per_page=-1'));
          $post_count = count($post_list);
          for ($q=0; $q<$post_count; $q++) {
          $post_list_by_ID[$q] = $post_list[$q][ID];
          }
          $lecture = array_search($post_ID,$post_list_by_ID);
          $percentage = ($lecture+1)/$post_count*100;
          $previous_post_ID = $post_list_by_ID[$lecture-1];
          $next_post_ID = $post_list_by_ID[$lecture+1];
          $notes = get_post_meta($post->ID, 'supplementary_notes',true);
        ?>
        <div class="span3 videoside fade in">
        <p class="lead">Topic Progress (<?php echo ($lecture+1); ?>/<?php echo $post_count; ?>)</p>
        <div class="progress">
        <?php
          echo '<div class="bar" style="width:'.$percentage.'%;"></div><!--bar-->'
        ?>
        </div><!--progress-->
        <div class="well sidebar visible-desktop">
          <ul class="nav nav-list">
            <li class="nav-header">Navigation</li>
            <li class="menu-icon">
            <?php
            if ($previous_post_ID==NULL) {
              echo '<i class="icon-chevron-left icon-large muted"></i>';
            }
            else {
              echo '<a href="'.get_permalink($previous_post_ID).'" rel="tooltip" title="Previous Lecture" class="tool"><i class="icon-chevron-left icon-large"></i></a>';
            }
            echo '<a href="'.get_category_link($parentcatID).'" rel="tooltip" title="Back to '.get_the_category_by_ID($parentcatID).'" class="tool"><i class="icon-chevron-up icon-large"></i></a>';
            if ($next_post_ID==NULL) {
              echo '<i class="icon-chevron-right icon-large muted"></i>';
            }
            else {
              echo '<a href="'.get_permalink($next_post_ID).'" rel="tooltip" title="Next Lecture" class="tool"><i class="icon-chevron-right icon-large"></i></a>';
            }
            ?>
            </li>
            <li class="nav-header">Sharing</li>
            <li class="menu-icon">
            <a href="#" rel="tooltip" title="Facebook" class="tool"><i class="icon-facebook-sign icon-large"></i></a>
            <a href="#" rel="tooltip" title="Twitter" class="tool"><i class="icon-twitter-sign icon-large"></i></a>
            <a href="#" rel="tooltip" title="Google Plus" class="tool"><i class="icon-plus icon-large"></i></a></li>
            <li class="nav-header">Community</li>
            <li class="menu-icon">
            <a href="#" rel="tooltip" title="Download Lecture" class="tool"><i class="icon-download-alt icon-large"></i></a>
            <a href="mailto:<?php the_author_email() ?>" rel="tooltip" title="Email Lecturer" class="tool"><i class="icon-envelope icon-large"></i></a>
            <a href="/errors" rel="tooltip" title="Report Error" class="tool"><i class="icon-exclamation-sign icon-large"></i></a>
            </li>
            <li class="nav-header">Landmarks</li>
            <?php
              $landmarkinput = get_post_meta($post->ID, 'lecture_landmarks', true);
              $landmarklist = explode(',',$landmarkinput);
              for ($q=0; $q<count($landmarklist); $q++) {
                $split[$q] = explode('-',$landmarklist[$q]);
                echo '<li id="'.$split[$q][0].'"><a onclick="jwplayer().seek('.$split[$q][0].')" style="cursor:pointer;"><strong>'.$split[$q][0].'</strong> - '.$split[$q][1].'</a></li>';
              }
            ?>
          </ul>
        </div><!--well-->
        <script>
        jQuery('.videoside').tooltip({
            selector: "a[rel=tooltip]"
          })
        </script>
        </div><!--span3-->
        </div><!--row-->
        <hr>
<div class="row">
  <div class="span3">
    <div class="well sidebar">
      <ul class="nav nav-list">
        <li class="nav-header">Chemistry</li>
        <li class="active"><a href="#">Atoms, Elements and Isotopes</a></li>
        <li><a href="#">Quantities Involving Atoms</a></li>
        <li><a href="#">Molecules and Ions</a></li>
        <li><a href="#">Formulae and Masses - Definitions</a></li>
        <li><a href="#">Formula and Mass Composition</a></li>
        <li><a href="#">Fundamentals of Mass Spectrometry</a></li>
      </ul>
    </div><!--well-->
  </div><!--span3-->
  <div class="span9">
<div class="accordion" id="accordion2">
  <?php if ($info) { ?>
  <div class="accordion-group">
    <div class="accordion-heading">
      <a class="accordion-toggle subheader" data-toggle="collapse" href="#info">
        Additional Information
      </a>
    </div>
    <div id="info" class="accordion-body collapse in">
      <div class="accordion-inner">
        <?php echo $info; ?>
      </div>
    </div>
  </div>
  <?php } ?>
  <?php if (get_the_content()) { ?>
  <div class="accordion-group">
    <div class="accordion-heading">
      <a class="accordion-toggle subheader" data-toggle="collapse" href="#transcript">
        Lecture Transcript
      </a>
    </div>
    <div id="transcript" class="accordion-body collapse">
      <div class="accordion-inner">
          <?php the_content(); ?>
      </div>
    </div>
    </div>
    <?php } ?>
</div>
</div><!--span9-->
</div><!--row-->
        <?php endif; ?>
  </div><!--container-->
          <?php get_footer(); ?>