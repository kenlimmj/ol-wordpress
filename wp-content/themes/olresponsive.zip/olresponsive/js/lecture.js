jwplayer('container').setup({
  'flashplayer': '/wp-content/themes/olresponsive/jwplayer/player.swf',
  'width':'100%',
  'height':'100%',
  'plugins': {
    // 'hd-2': {'state': 'true'},
    // 'lightsout-1': {}
  },
  'controlbar': 'bottom',
  'logo': {
    'file': '/wp-content/themes/olresponsive/img/Logo-Player.png',
    'position': 'top-left',
  },
  'skin': 'http://localhost/wp-content/themes/olresponsive/jwplayer/schoon/schoon.zip',
  'screencolor': 'ffffff',
});